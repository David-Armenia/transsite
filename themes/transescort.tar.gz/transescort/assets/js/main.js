/* =================================
   Search filter (cards)
================================= */
document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.querySelector('.search-input');
  const cards = document.querySelectorAll('.card');

  if (!searchInput || !cards.length) return;

  searchInput.addEventListener('input', () => {
    const query = searchInput.value.toLowerCase().trim();

    cards.forEach(card => {
      const text = card.innerText.toLowerCase();
      card.style.display = text.includes(query) ? '' : 'none';
    });
  });
});


/* =================================
   Request form (AJAX) — SINGLE handler
================================= */
document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('.request-form');
  const resultBox = document.querySelector('.request-result');

  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    if (resultBox) {
      resultBox.style.display = 'none';
      resultBox.textContent = '';
    }

    const fd = new FormData(form);
    fd.append('action', 'transescort_create_request');
    fd.append('nonce', (window.TRANS && TRANS.nonce) ? TRANS.nonce : '');
      const pid = form.dataset.profile ? String(form.dataset.profile) : "";
      if (pid) fd.append("profile_id", pid);


    try {
      const res = await fetch((window.TRANS && TRANS.ajaxurl) ? TRANS.ajaxurl : "/wp-admin/admin-ajax.php", {
        method: 'POST',
        credentials: 'same-origin',
        body: fd
      });

      const data = await res.json();

      if (resultBox) {
        resultBox.classList.remove("is-success", "is-error");

        if (data.success) {
          resultBox.classList.add("is-success");
          resultBox.textContent = (data.data?.message || "Заявка отправлена ✅");
        } else {
          resultBox.classList.add("is-error");
          resultBox.textContent = (data.data?.message || "Ошибка. Попробуйте ещё раз.");
        }

        resultBox.style.display = "block";
        resultBox.scrollIntoView({ behavior: "smooth", block: "center" });
      }

      if (data.success) {
        form.reset();
      }
    } catch (err) {
      if (resultBox) {
        resultBox.textContent = 'Server error. Try again.';
        resultBox.style.display = 'block';
      }
    }
  });
});


/* =================================
   Video modal
================================= */
(function () {
  const modal = document.getElementById('videoModal');
  const player = document.getElementById('videoModalPlayer');
  if (!modal || !player) return;

  function openModal(url) {
    if (!url) return;

    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');

    player.pause();
    player.removeAttribute('src');
    player.load();

    player.src = url;
    player.load();
    player.play().catch(() => {});
  }

  function closeModal() {
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');

    player.pause();
    player.removeAttribute('src');
    player.load();
  }

  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.video-open');
    if (btn) {
      openModal(btn.getAttribute('data-video'));
      return;
    }

    if (
      e.target?.getAttribute?.('data-close') === '1'
    ) {
      closeModal();
    }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('is-open')) {
      closeModal();
    }
  });
})();


/* =================================
   Gallery lightbox (profiles)
================================= */
(function(){
  const lb = document.getElementById('galleryLightbox');
  const img = document.getElementById('galleryLightboxImg');
  if (!lb || !img) return;

  document.addEventListener('click', (e) => {
    const item = e.target.closest('.profile-gallery-item');
    if (item) {
      const full = item.dataset.full;
      if (!full) return;

      img.src = full;
      lb.classList.add('is-open');
      lb.setAttribute('aria-hidden','false');
      return;
    }

    if (
      e.target.classList.contains('gallery-lightbox__backdrop') ||
      e.target.classList.contains('gallery-lightbox__close')
    ) {
      lb.classList.remove('is-open');
      lb.setAttribute('aria-hidden','true');
      img.src = '';
    }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && lb.classList.contains('is-open')) {
      lb.classList.remove('is-open');
      lb.setAttribute('aria-hidden','true');
      img.src = '';
    }
  });
})();


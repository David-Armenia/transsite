<?php
$city = (string) get_query_var('te_city');
if (!$city) $city = 'Москва';

$q = new WP_Query([
  'post_type'      => 'profile',
  'post_status'    => 'publish',
  'posts_per_page' => 8,
  'orderby'        => 'date',
  'order'          => 'DESC',
  'meta_query'     => [
    [
      'key'     => '_profile_city',
      'value'   => $city,
      'compare' => 'LIKE'
    ]
  ],
]);
?>

<section class="home-section home-city">
  <div class="container">

    <div class="section-head section-head--spaced">
      <h2 class="section-title">Транссексуалы г. <?php echo esc_html($city); ?></h2>
    </div>

    <div class="city-grid">
      <!-- Left info card (Figma) -->
      <aside class="city-info">
        <div class="city-info__card">
          <div class="city-info__top">
            <div class="city-info__title">Каталог анкет</div>
            <div class="city-info__subtitle">
              Выберите анкету, посмотрите фото, цены и доступность. Можно отправить заявку прямо на странице профиля.
            </div>
          </div>

          <div class="city-info__actions">
            <a class="btn btn-primary" href="<?php echo esc_url(get_post_type_archive_link('profile')); ?>">
              Перейти в каталог
            </a>
            <a class="city-info__arrow" href="<?php echo esc_url(get_post_type_archive_link('profile')); ?>" aria-label="Go to catalog">→</a>
          </div>

          <div class="city-info__note">
            * Далее сделаем фильтр города/поиск строго по Figma.
          </div>
        </div>
      </aside>

      <!-- Profiles grid -->
      <div class="city-cards">
        <?php if (!$q->have_posts()): ?>
          <p class="section-muted">Пока нет анкет для этого города.</p>
        <?php else: ?>
          <div class="cards-grid cards-grid--city">
            <?php while ($q->have_posts()): $q->the_post(); ?>
              <?php get_template_part('template-parts/components/profile-card'); ?>
            <?php endwhile; wp_reset_postdata(); ?>
          </div>
        <?php endif; ?>
      </div>
    </div>

  </div>
</section>


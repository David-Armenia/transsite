<?php
get_header();

$profile_id = get_the_ID();

$price    = get_post_meta($profile_id, '_profile_price', true);
$city     = get_post_meta($profile_id, '_profile_city', true);
$verified = get_post_meta($profile_id, '_profile_verified', true) === '1';

/**
 * Определяем владельца профиля
 */
$owner_id      = (int) get_post_meta($profile_id, '_profile_user_id', true);
$is_owner_meta = is_user_logged_in() && get_current_user_id() === $owner_id;

/**
 * Проверка привязки профиля к пользователю
 */
$linked_profile_id = (int) get_user_meta(get_current_user_id(), '_linked_profile_id', true);
$is_owner_linked   = is_user_logged_in() && ($linked_profile_id === $profile_id);

/**
 * Итоговое право на редактирование
 */
$is_owner = $is_owner_meta || $is_owner_linked;
?>

<main class="site-main">

<section class="profile">

  <div class="container profile-grid">

    <!-- LEFT -->
    <div class="profile-left">

      <!-- Gallery -->
      <?php
      $gallery_ids = get_post_meta($profile_id, '_profile_gallery_ids', true);
      if (!is_array($gallery_ids)) $gallery_ids = [];
      ?>

      <?php if ($gallery_ids): ?>
        <div class="profile-gallery" id="profileGallery">
          <?php foreach ($gallery_ids as $i => $img_id): ?>
            <?php
              $full  = wp_get_attachment_image_url($img_id, 'full');
              $thumb = wp_get_attachment_image_url($img_id, 'large');
              if (!$thumb) $thumb = wp_get_attachment_image_url($img_id, 'full');
            ?>
            <button
              class="profile-gallery-item <?php echo $i === 0 ? 'is-main' : ''; ?>"
              style="background-image:url('<?php echo esc_url($thumb); ?>')"
              data-full="<?php echo esc_url($full); ?>"
              aria-label="Open image"
              type="button"
            ></button>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="profile-gallery">
          <?php if (has_post_thumbnail()): ?>
            <?php the_post_thumbnail('large'); ?>
          <?php else: ?>
            <div class="profile-gallery-placeholder"></div>
          <?php endif; ?>
        </div>
      <?php endif; ?>


      <!-- Videos -->
      <?php
      $videos_q = new WP_Query([
        'post_type'      => 'video',
        'post_status'    => 'publish',
        'posts_per_page' => 6,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'meta_query'     => [
          [
            'key'     => '_video_profile_id',
            'value'   => $profile_id,
            'compare' => '='
          ]
        ],
      ]);
      ?>

      <?php if ($videos_q->have_posts()): ?>
        <div class="profile-card">
          <div class="profile-block-head">
            <h2 class="profile-block-title">Видео</h2>
          </div>

          <div class="profile-videos">
            <?php while ($videos_q->have_posts()): $videos_q->the_post(); ?>
              <?php
                $video_id  = get_the_ID();
                $att_id    = (int) get_post_meta($video_id, '_video_attachment_id', true);
                $url       = $att_id ? wp_get_attachment_url($att_id) : '';
                $dur       = get_post_meta($video_id, '_video_duration', true);
                $cover_id  = (int) get_post_meta($video_id, '_video_cover_id', true);
                $cover_url = $cover_id ? wp_get_attachment_image_url($cover_id, 'large') : '';
              ?>

              <?php if ($url): ?>
                <article class="pv-card">
                  <button
                    class="pv-media video-open"
                    type="button"
                    data-video="<?php echo esc_url($url); ?>"
                    <?php if ($cover_url): ?>
                      style="background-image:url('<?php echo esc_url($cover_url); ?>')"
                    <?php endif; ?>
                  >
                    <span class="pv-play">▶</span>
                    <?php if ($dur): ?>
                      <span class="pv-duration"><?php echo esc_html($dur); ?></span>
                    <?php endif; ?>
                  </button>

                  <div class="pv-body">
                    <div class="pv-title"><?php the_title(); ?></div>
                    <div class="pv-meta"><?php echo esc_html(get_the_date('d.m.Y')); ?></div>
                  </div>
                </article>
              <?php endif; ?>

            <?php endwhile; wp_reset_postdata(); ?>
          </div>
        </div>
      <?php endif; ?>


      <!-- Description -->
      <div class="profile-card">
        <h2>Описание</h2>
        <div class="profile-text">
          <?php the_content(); ?>
        </div>
      </div>

      <!-- Request form -->
      <div class="profile-card">
        <h2>Оставить заявку</h2>

        <form class="request-form" data-profile="<?php echo esc_attr($profile_id); ?>">
          <input type="text" name="name" placeholder="Ваше имя" required>
          <input type="text" name="contact" placeholder="Контакт (Telegram / Phone)" required>
          <input type="datetime-local" name="datetime" required>
          <textarea name="message" placeholder="Комментарий"></textarea>

          <button class="btn btn-primary" type="submit">Отправить</button>
        </form>
          <div class="request-result" style="display:none; margin-top:12px;"></div>
      </div>

    </div>

    <!-- RIGHT -->
    <aside class="profile-right">

      <div class="profile-summary">

        <h1 class="profile-name">
          <?php the_title(); ?>
          <?php if ($verified): ?>
            <span class="profile-badge">Verified</span>
          <?php endif; ?>
        </h1>

        <?php if ($city): ?>
          <div class="profile-city"><?php echo esc_html($city); ?></div>
        <?php endif; ?>

        <?php if ($price): ?>
          <div class="profile-price"><?php echo esc_html($price); ?></div>
        <?php endif; ?>

        <?php if ($is_owner): ?>
          <a href="<?php echo esc_url(home_url('/personal-profile/')); ?>" class="btn btn-primary">
            Редактировать профиль
          </a>
        <?php endif; ?>

      </div>

    </aside>

  </div>

</section>

</main>

<?php get_footer(); ?>

<?php
$gallery_ids = get_post_meta(get_the_ID(), '_profile_gallery_ids', true);
if (!is_array($gallery_ids)) $gallery_ids = [];
$gallery_ids = array_values(array_unique(array_map('intval', $gallery_ids)));
?>

<?php if (!empty($gallery_ids)): ?>
  <div class="profile-gallery">
    <?php foreach ($gallery_ids as $att_id): ?>
      <?php
        $img = wp_get_attachment_image_src($att_id, 'medium');
        if (!$img) continue;
        $full = wp_get_attachment_image_src($att_id, 'full');
        $href = $full ? $full[0] : $img[0];
      ?>
      <a class="profile-gallery-item" href="<?php echo esc_url($href); ?>" target="_blank" rel="noopener"
         style="background-image:url('<?php echo esc_url($img[0]); ?>');"></a>
    <?php endforeach; ?>
  </div>
<?php endif; ?>


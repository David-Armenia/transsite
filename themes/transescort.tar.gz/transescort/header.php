<!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header">
  <div class="container header-inner">

    <div class="logo">
      <a href="<?php echo esc_url(home_url('/')); ?>">TransEscort</a>
    </div>

    <nav class="nav">
      <?php
      wp_nav_menu([
        'theme_location' => 'primary',
        'container'      => false,
        'fallback_cb'    => '__return_empty_string',
        'menu_class'     => 'menu',
      ]);
      ?>
    </nav>

    <!-- AUTH ACTIONS -->
    <div class="header-auth">
      <?php if (is_user_logged_in()): ?>
        <a
          href="<?php echo esc_url(wp_logout_url(home_url('/login/'))); ?>"
          class="btn btn-logout"
        >
          Logout
        </a>
      <?php else: ?>
        <a
          href="<?php echo esc_url(home_url('/login/')); ?>"
          class="btn btn-login"
        >
          Login
        </a>
      <?php endif; ?>
    </div>

  </div>
</header>


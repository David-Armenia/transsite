<section class="hero">
  <div class="container hero-inner">

    <!-- LEFT -->
    <div class="hero-left">

      <div class="hero-tariff-card">
        <h3 class="hero-tariff-title">Тарифы</h3>
        <p class="hero-tariff-text">
          Не упусти возможность изучить наши специальные предложения по тарифам,
          чтобы найти больше возможностей и преимуществ.
        </p>

        <a href="#" class="btn btn-primary hero-tariff-btn">
          Посмотреть
        </a>
      </div>

      <a href="#" class="hero-preview">
        <img
          src="<?php echo get_template_directory_uri(); ?>/assets/img/hero-preview.jpg"
          alt=""
          loading="lazy"
        />
        <span class="hero-preview-btn">Перейти к анкете →</span>
      </a>

    </div>

    <!-- RIGHT -->
    <div class="hero-right">

      <div class="hero-bg">
        <img
          src="<?php echo get_template_directory_uri(); ?>/assets/img/hero-bg.jpg"
          alt=""
        />
      </div>

      <div class="hero-content">
        <h1 class="hero-title hero-brand">
          Trans<br>Escort
        </h1>

        <div class="hero-stats">
          <div class="hero-stat">
            <strong>500+</strong>
            <span>человек<br>пользуются нашими услугами</span>
          </div>
          <div class="hero-stat">
            <strong>150+</strong>
            <span>Анкет<br>прошедших проверку</span>
          </div>
        </div>
      </div>

    </div>

  </div>
</section>


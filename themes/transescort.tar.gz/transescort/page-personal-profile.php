<?php
/**
 * Template Name: Personal Profile
 */

get_header();

if (!is_user_logged_in()) {
  wp_safe_redirect(home_url('/login/'));
  exit;
}

$user_id = get_current_user_id();
$profile_id = (int) transescort_get_linked_profile_id($user_id);

if (!$profile_id) : ?>
  <main class="site-main">
    <section class="container pp">
      <h1 class="page-title">Personal profile</h1>
      <p class="pp-muted">No linked profile found for your account.</p>
    </section>
  </main>
<?php
  get_footer();
  exit;
endif;

// Extra safety: owner/admin only
$can_view = current_user_can('administrator') || transescort_user_owns_profile($user_id, $profile_id);
if (!$can_view) {
  wp_die('Access denied', 'Access denied', ['response' => 403]);
}

// Profile meta
$price    = get_post_meta($profile_id, '_profile_price', true);
$city     = get_post_meta($profile_id, '_profile_city', true);
$verified = get_post_meta($profile_id, '_profile_verified', true);
$is_verified = ($verified === '1');

$profile_url = get_permalink($profile_id);
$edit_url    = get_edit_post_link($profile_id, '');

// Gallery meta (array of attachment IDs)
$gallery_ids = get_post_meta($profile_id, '_profile_gallery_ids', true);
if (!is_array($gallery_ids)) $gallery_ids = [];
$gallery_ids = array_values(array_unique(array_map('intval', $gallery_ids)));

// Upload status from redirect
$upload_status = isset($_GET['upload']) ? sanitize_text_field($_GET['upload']) : '';
$deleted = isset($_GET['deleted']) ? sanitize_text_field($_GET['deleted']) : '';
?>

<main class="site-main">
  <section class="container pp">

    <header class="pp-header">
      <div class="pp-head-left">
        <h1 class="pp-title">
          <?php echo esc_html(get_the_title($profile_id)); ?>
          <?php if ($is_verified): ?>
            <span class="pp-badge">Verified</span>
          <?php endif; ?>
        </h1>

        <div class="pp-sub">
          <?php if ($city): ?>
            <span class="pp-sub-item"><?php echo esc_html($city); ?></span>
          <?php endif; ?>

          <?php if ($price): ?>
            <span class="pp-sub-item"><?php echo esc_html($price); ?></span>
          <?php endif; ?>
        </div>
      </div>

      <div class="pp-actions">
        <a class="btn btn-outline" href="<?php echo esc_url($profile_url); ?>">Open public</a>
        <?php if ($edit_url): ?>
          <a class="btn btn-primary" href="<?php echo esc_url($edit_url); ?>">Edit (admin)</a>
        <?php endif; ?>
      </div>
    </header>

    <div class="pp-grid">
      <!-- LEFT -->
      <div class="pp-left">

        <!-- Gallery -->
        <section class="pp-card">
          <h2 class="pp-section-title">Gallery</h2>

          <?php if ($upload_status === 'ok'): ?>
            <div class="pp-alert pp-alert--success" style="margin:10px 0;">
              Photos uploaded successfully.
            </div>
          <?php elseif ($upload_status === 'no_files'): ?>
            <div class="pp-alert pp-alert--error" style="margin:10px 0;">
              No files selected.
            </div>
          <?php endif; ?>

          <?php if ($deleted === '1'): ?>
            <div class="pp-alert pp-alert--success" style="margin:10px 0;">
              Photo deleted.
            </div>
          <?php endif; ?>

          <!-- Upload form -->
          <form method="post" enctype="multipart/form-data" class="pp-upload-form">
            <?php wp_nonce_field('transescort_profile_upload'); ?>
            <input type="hidden" name="action" value="transescort_upload_photos">

            <label class="pp-upload-select">
              <input type="file" name="photos[]" multiple accept="image/*" hidden>
              Upload photos
            </label>

            <button type="submit" class="pp-upload-btn">
              Upload photos
            </button>
          </form>

          <?php if (!empty($gallery_ids)): ?>
            <div class="pp-gallery">
              <?php foreach ($gallery_ids as $att_id): ?>
                <?php
                  $att_id = (int) $att_id;
                  if (!$att_id) continue;

                  // Fallback: if medium not generated, use full
                  $thumb = wp_get_attachment_image_url($att_id, 'medium');
                  $full  = wp_get_attachment_image_url($att_id, 'full');

                  $url = $thumb ?: $full;
                  if (!$url) continue;

                  $href = $full ?: $url;
                ?>

                <div class="pp-gallery-item" style="background-image:url('<?php echo esc_url($url); ?>');">
                  <!-- open photo -->
                  <a class="pp-gallery-open" href="<?php echo esc_url($href); ?>" target="_blank" rel="noopener"></a>

                  <!-- delete button (on hover) -->
                  <form method="post" class="pp-photo-del-form" onsubmit="return confirm('Delete this photo?');">
                    <?php wp_nonce_field('delete_profile_photo'); ?>
                    <input type="hidden" name="action" value="delete_profile_photo">
                    <input type="hidden" name="att_id" value="<?php echo (int) $att_id; ?>">
                    <button type="submit" class="pp-photo-del-btn">Delete</button>
                  </form>
                </div>

              <?php endforeach; ?>
            </div>
          <?php else: ?>
            <p class="pp-muted">No photos yet. Upload your first photos above.</p>
          <?php endif; ?>

          <p class="pp-hint" style="margin-top:12px;">
            Next: we will style gallery + lightbox according to Figma.
          </p>
        </section>

        <!-- Activity / tariffs placeholder -->
        <section class="pp-card pp-card--mt">
          <h2 class="pp-section-title">Tariffs & Activity</h2>
          <p class="pp-muted">Placeholder. Next step: connect pricing blocks and activity UI from Figma 8/16.</p>
        </section>

      </div>

      <!-- RIGHT -->
      <aside class="pp-right">

        <!-- Quick info -->
        <section class="pp-card">
          <h2 class="pp-section-title">Info</h2>

          <div class="pp-info">
            <div class="pp-info-row"><strong>City:</strong> <?php echo esc_html($city ?: '—'); ?></div>
            <div class="pp-info-row"><strong>Price:</strong> <?php echo esc_html($price ?: '—'); ?></div>
            <div class="pp-info-row"><strong>Status:</strong> <?php echo $is_verified ? 'Verified' : 'Not verified'; ?></div>
          </div>


<?php if (isset($_GET["saved"]) && $_GET["saved"] === "city"): ?>
  <div class="pp-alert pp-alert--success" style="margin:10px 0;">
    Город сохранён ✅
  </div>
<?php endif; ?>

<form method="post" class="pp-card pp-card--mt" style="padding:0;border:0;background:transparent;box-shadow:none;">
  <?php wp_nonce_field("transescort_save_profile_city", "transescort_save_profile_city_nonce"); ?>
  <input type="hidden" name="action" value="transescort_save_profile_city">

  <div class="pp-info" style="margin-top:10px;">
    <div class="pp-info-row"><strong>Change city:</strong></div>

    <select name="profile_city" style="width:100%; margin-top:8px;">
      <?php foreach (transescort_city_list() as $val => $label): ?>
        <option value="<?php echo esc_attr($val); ?>" <?php selected((string)$city, (string)$val); ?>>
          <?php echo esc_html($label); ?>
        </option>
      <?php endforeach; ?>
    </select>

    <button type="submit" class="btn btn-primary" style="margin-top:12px;">Сохранить</button>
  </div>
</form>


          </section>

          <!-- Requests (last 5) -->
        <section class="pp-card pp-card--mt">
          <h2 class="pp-section-title">Latest Requests</h2>

          <?php
            $requests = transescort_get_profile_requests($profile_id, 5);
            if (empty($requests)):
          ?>
            <p class="pp-muted">No requests yet.</p>
          <?php else: ?>
            <div class="pp-requests-list">
              <?php foreach ($requests as $r): ?>
                <?php
                  $status   = transescort_get_request_status($r->ID);
                  $name     = get_post_meta($r->ID, '_request_name', true);
                  $contact  = get_post_meta($r->ID, '_request_contact', true);
                  $dt       = get_post_meta($r->ID, '_request_datetime', true);
                  $label    = transescort_request_status_label($status);
                ?>

                <div class="pp-request-item">
                  <div class="pp-request-top">
                    <div class="pp-request-person">
                      <?php echo esc_html($name ?: '—'); ?>
                      <span class="pp-request-contact">— <?php echo esc_html($contact ?: ''); ?></span>
                    </div>

                    <div class="request-status status-<?php echo esc_attr($status); ?>">
                      <?php echo esc_html($label); ?>
                    </div>
                  </div>

                  <?php if ($dt): ?>
                    <div class="pp-request-dt"><?php echo esc_html($dt); ?></div>
                  <?php endif; ?>
                </div>

              <?php endforeach; ?>
            </div>

            <div class="pp-actions-row">
              <a class="btn btn-outline" href="<?php echo esc_url(home_url('/account/')); ?>">
                View all in Account
              </a>
            </div>
          <?php endif; ?>
        </section>

      </aside>
    </div>

  </section>
</main>

<?php get_footer(); ?>

